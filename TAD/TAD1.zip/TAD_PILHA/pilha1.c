#include <stdio.h>
#include <stdlib.h>
#include "pilha1.h"


Pilha* cria_pilha(){
    Pilha* ptr = (Pilha*)malloc(sizeof(Pilha));
    if(ptr == NULL){
        return 0;
    }
    return ptr;
}

void destruir(Pilha *p1){
    free(p1);
}

int tamanho(Pilha *pi){
    if(pi == NULL)
        return -1;
    return pi->qtd;
}


int inserir_Pilha(Pilha *pi, struct aluno al){

    if(pi == NULL || pi->qtd == MAX){
        return 0;
    }
    
    pi->dados[pi->qtd] = al;
    pi->qtd++;

    return 1;
}
int remover_Pilha(Pilha *pi){
    if(pi== NULL || pi->qtd==0){
        return 0;
    }
     pi->qtd--;
     return 1;


}

#define MAX 100
struct aluno{
    char nome[30];
    int mat;
};

struct pilha{
    int qtd;
    struct aluno dados[MAX];
};

typedef struct pilha Pilha;

Pilha* cria_pilha();

void destruir(Pilha *pi);

int tamanho(Pilha *pi);

int inserir_Pilha(Pilha *pi, struct aluno al);

int remover_Pilha(Pilha *pi);